class AppRouteName {
  static const String splash = "/splash";
  static const String home = "/";
  static const String movieDetail = "/movie-detail";
  static const String movieBooking = "/movie-booking";
}
